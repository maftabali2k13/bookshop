using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Services.Models.Dto;
using Services.Repository;

namespace Services.Controllers
{
    [Route("api/products")]
    public class ProductAPIController : ControllerBase
    {
        //private readonly ILogger<ProductAPIController> _logger;
        protected ResponseDto _response; 
        private IProductRepository _repository;

        public ProductAPIController(IProductRepository productRepository)
        {
            _repository = productRepository;
            _response = new ResponseDto();
        }

       [HttpGet]

       public async Task<ResponseDto> Get()
       {
           try
           {
               IEnumerable<ProductDto> productDtos = await _repository.GetProducts();
               _response.Result = productDtos;
           }
           catch (Exception ex)
           {
               
               _response.IsSuccess = false;
               _response.ErrorMessages = new List<string>() { ex.ToString()};
            
           }

           return _response;
       }

       [HttpGet]
       [Route("{id}")]

       public async Task<ResponseDto> Get(int id)
       {
           try
           {
               ProductDto productDto = await _repository.GetProductById(id);
               _response.Result = productDto;
           }
           catch (Exception ex)
           {
               
               _response.IsSuccess = false;
               _response.ErrorMessages = new List<string>() { ex.ToString()};
            
           }

           return _response;
       }

       [HttpPost]

       public async Task<ResponseDto> Post([FromBody] ProductDto productDto)
       {
           try
           {
               ProductDto entity = await _repository.CreateUpdateProduct(productDto);
               _response.Result = entity;
           }
           catch (Exception ex)
           {
               
               _response.IsSuccess = false;
               _response.ErrorMessages = new List<string>() { ex.ToString()};
            
           }

           return _response;
       }

       [HttpPut]

       public async Task<ResponseDto> Put([FromBody] ProductDto productDto)
       {
           try
           {
               ProductDto entity = await _repository.CreateUpdateProduct(productDto);
               _response.Result = entity;
           }
           catch (Exception ex)
           {
               
               _response.IsSuccess = false;
               _response.ErrorMessages = new List<string>() { ex.ToString()};
            
           }

           return _response;
       }

       [HttpDelete]

       public async Task<ResponseDto> Delete(int id)
       {
           try
           {
               bool IsDeleted = await _repository.DeleteProduct(id);
               _response.IsSuccess = IsDeleted;
               
           }
           catch (Exception ex)
           {
               
               _response.IsSuccess = false;
               _response.ErrorMessages = new List<string>() { ex.ToString()};
            
           }

           return _response;
       }


    }
}